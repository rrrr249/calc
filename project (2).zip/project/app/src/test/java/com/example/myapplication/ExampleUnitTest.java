// Класс exampleunittest,
// содержит метод addition_iscorrect для тестирования сложения двух чисел.
package com.example.myapplication;

import org.junit.Test;

import static org.junit.Assert.*;


public class ExampleUnitTest {
    /**
     * Тестовый метод для проверки корректности сложения двух чисел.
     * Этот метод использует утверждение assertEquals для сравнения результата сложения числа 2 и 2 с ожидаемым значением 4.
     */

    // аннотация, указывающая, что метод будет тестом
    @Test

    // Проверка, что результат сложения 2 + 2 действительно равен 4.
    // Если условие не выполняется, тест считается не пройденным.
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}