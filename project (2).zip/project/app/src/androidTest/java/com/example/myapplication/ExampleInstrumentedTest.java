package com.example.myapplication;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;


@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    // Определяется метод useAppContext, который тестирует контекст приложения:
    @Test
    public void useAppContext() {

        // Получение контекста приложения через Инструментационную Библиотеку.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();

        // Проверка, что пакетное имя контекста приложения соответствует ожидаемому.
        // Если условие не выполняется, тест будет считаться проваленным.
        assertEquals("com.example.myapplication", appContext.getPackageName());
    }
}